﻿Elementor Halloween Icon Pack


The team at Elementor is happy to offer you this free Halloween set of 49 unique icons. These icons are free to use only on your websites and on your clients' websites for your enjoyment. The license doesn’t cover use for print purposes.


The icons were created by the talented designers of icon54.com


Happy Halloween!